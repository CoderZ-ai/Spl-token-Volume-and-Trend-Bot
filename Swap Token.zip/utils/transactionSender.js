import { Connection, TransactionExpiredBlockheightExceededError } from '@solana/web3.js';
import promiseRetry from 'promise-retry';

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const SEND_OPTIONS = {
  skipPreflight: true,
};

export async function transactionSenderAndConfirmationWaiter({ connection, serializedTransaction, blockhashWithExpiryBlockHeight }) {
  const txid = await connection.sendRawTransaction(serializedTransaction, SEND_OPTIONS);

  const controller = new AbortController();
  const abortSignal = controller.signal;

  const abortableResender = async () => {
    while (true) {
      await wait(2000);
      if (abortSignal.aborted) return;
      try {
        await connection.sendRawTransaction(serializedTransaction, SEND_OPTIONS);
      } catch (e) {
        console.warn(`Failed to resend transaction: ${e}`);
      }
    }
  };

  try {
    abortableResender();
    const lastValidBlockHeight = blockhashWithExpiryBlockHeight.lastValidBlockHeight;
    await Promise.race([
      connection.confirmTransaction(
        {
          ...blockhashWithExpiryBlockHeight,
          lastValidBlockHeight: lastValidBlockHeight,
          signature: txid,
          abortSignal: abortSignal,
        },
        "confirmed"
      ),
      new Promise(async (resolve) => {
        while (!abortSignal.aborted) {
          await wait(2000);
          const tx = await connection.getSignatureStatus(txid, {
            searchTransactionHistory: false,
          });
          if (tx?.value?.confirmationStatus === "confirmed") {
            resolve(tx);
          }
        }
      }),
    ]);
  } catch (e) {
    if (e instanceof TransactionExpiredBlockheightExceededError) {
      return null;
    } else {
      throw e;
    }
  } finally {
    controller.abort();
  }

  const response = await promiseRetry(
    async (retry) => {
      const response = await connection.getTransaction(txid, {
        commitment: "confirmed",
        maxSupportedTransactionVersion: 0,
      });
      if (!response) {
        retry(response);
      }
      return response;
    },
    {
      retries: 5,
      minTimeout: 1e3,
    }
  );

  return response;
}
